clc,clear
