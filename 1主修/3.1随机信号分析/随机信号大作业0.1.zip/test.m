clc,clear
close all
fs=1000;%采样频率hz
T_N=1.5;%总时间s
t=1/fs:1/fs:T_N;%时间向量
L=T_N*fs;%样本长度
y=12*cos((2*pi)*100.*t)+15*cos((2*pi)*150.*t)+18*cos((2*pi)*210.*t)+10;%信号
subplot(2,1,1);
plot(t,y);
xlabel("时间/s")
ylabel("幅度/v")
title("时域")
fft_y=fft(y);%快速傅里叶变换
P = abs(fft_y/L);%取幅频特性，除以L
P = P(1:L/2+1);%截取前半段
P(2:end-1)=2*P(2:end-1);%单侧频谱非直流分量记得乘以2
f = fs*(0:(L/2))/L;%频率，最多到一半（奈奎斯特采样定理）
subplot(2,1,2);
plot(f,P);
xlabel("频率/Hz")
ylabel("幅度/v")
title("单边频谱")

figure(4)
[r,lags]=xcorr(y,'biased');%得到自相关函数的幅度和偏移量
% subplot(2,1,1)
% plot(lags,r)
% xlabel("时间偏移/s")
% ylabel("相关程度")
% title("（自相关函数）")

fft_y=fftshift(fft_y);%频谱矫正
powerpu=abs(fft_y./L).^2;%双边功率谱
subplot(2,1,1)
plot((1:size(powerpu,2))-751,powerpu)
xlabel("频率/Hz")
ylabel("功率/W")
title("功率谱")

pdv=fft(r,size(r,2));%对自相关函数快速傅里叶变换
pdv=abs(fftshift(pdv));%频谱矫正，让正半轴部分和负半轴部分的图像分别关于各自的中心对称，得到双边谱
subplot(2,1,2)
plot((1:length(pdv))*L/length(pdv)-L/2,pdv./length(powerpu))
xlabel("频率/Hz")
ylabel("功率谱W/Hz")
title("（功率谱）")

% z1=0.1*randn(1,201);%产生方差N(0,0.12)高斯白噪声
% [r1,lags]=xcorr(z1,'unbiased');%自相关函数的估计
% plot(lags,r1);
% f1=fft(r1);
% f2=fftshift(f1);%频谱校正
% l1=((0:length(f2)-1)*200/length(f2)-100);%功率谱密度x轴
% y4=abs(f2);
% figure(2)
% plot(l1,y4);