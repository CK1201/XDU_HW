clc,clear
close all
t=0:0.001:10;
phi=rand(1,3)*2*pi;
x(1,:)=5*cos(t+phi(1));
x(2,:)=5*cos(t+phi(2));
x(3,:)=5*cos(t+phi(3));
figure()
hold on
plot(t,x(1,:))
plot(t,x(2,:))
plot(t,x(3,:))
xlabel('时间')
ylabel('幅度')
grid on